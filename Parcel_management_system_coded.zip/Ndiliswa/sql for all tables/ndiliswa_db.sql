-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2022 at 10:05 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ndiliswa_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `Branch_id` int(11) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Zip_code` int(4) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`Branch_id`, `Address`, `Zip_code`, `Contact`, `Email`, `Dated`) VALUES
(100323, '1003 Pretoria Branch', 727, 124477475, 'pta@ideliveries.com', '2022-07-06 17:55:17'),
(100325, '3001 Germiston Branch', 834, 12445894, 'gms@ideliveries.com', '2022-07-06 17:55:30'),
(100326, 'Johannesburg Head Office', 123, 125547894, 'jhb@ideliveries.com', '2022-07-06 17:53:54'),
(100327, 'Kwa zulu natal', 785, 124457895, 'kzn@ideliveries.com', '2022-07-07 07:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `dealerships`
--

CREATE TABLE `dealerships` (
  `D_id` int(10) NOT NULL,
  `D_name` varchar(50) NOT NULL,
  `D_email` varchar(50) NOT NULL,
  `D_tell_no` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `requests` varchar(50) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dealerships`
--

INSERT INTO `dealerships` (`D_id`, `D_name`, `D_email`, `D_tell_no`, `username`, `password`, `requests`, `dated`) VALUES
(2, 'iCourier', 'icourier@gmail.com', 124457895, 'icourier', '12345', 'Accepted', '2022-07-05 11:44:10');

-- --------------------------------------------------------

--
-- Table structure for table `parcel`
--

CREATE TABLE `parcel` (
  `Parcel_Id` int(10) NOT NULL,
  `Track_Id` bigint(10) NOT NULL,
  `S_Name` varchar(50) NOT NULL,
  `S_Addr` varchar(50) NOT NULL,
  `S_Contact` int(10) NOT NULL,
  `R_Name` varchar(50) NOT NULL,
  `R_Addr` varchar(50) NOT NULL,
  `R_Contact` int(10) NOT NULL,
  `Parcel_type` varchar(50) NOT NULL,
  `Weight_kg` int(5) NOT NULL,
  `Price` int(5) NOT NULL,
  `From_branch` varchar(50) NOT NULL,
  `To_branch` varchar(50) NOT NULL,
  `Dispatched_Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Checkout` varchar(50) NOT NULL,
  `Current_Location` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parcel`
--

INSERT INTO `parcel` (`Parcel_Id`, `Track_Id`, `S_Name`, `S_Addr`, `S_Contact`, `R_Name`, `R_Addr`, `R_Contact`, `Parcel_type`, `Weight_kg`, `Price`, `From_branch`, `To_branch`, `Dispatched_Time`, `Checkout`, `Current_Location`, `Status`) VALUES
(3, 1507761732, 'Pontsho Mohloding', 'Tembisa, 4001', 734474478, 'Clearence Modika', 'Germiston , 0112', 74412457, 'Box', 100, 102, '1002 Tembisa branch', '3000 Germiston branch', '2022-07-06 19:08:53', 'Paid', 'Tembisa branch', 'Ready to be Collected'),
(11, 2081329497, 'Maile Rababalela', 'Pretoria', 824457895, 'Nonfundo Zulu', 'Johannesburg', 1234, 'Furniture', 20, 560, 'Pretoria 0001', 'Germiston', '2022-07-06 19:09:53', 'Paid', 'Germiston', 'Collected'),
(12, 1642051219, 'Themba Mbatha', 'Mpumalanga', 726607141, 'Victor', 'Pretoria', 647784524, 'Plastic', 10, 1200, 'Mpumalanga', 'Pretoria', '2022-07-06 19:12:04', 'Paid', 'Germiston', 'Order is Shipped'),
(14, 2096309026, 'Masshodo Gigaba', 'KZN 0124', 785542148, 'Simpiwe Ndaba', 'KZN 0131', 725524862, 'Gadget', 100, 5000, 'Kwa zulu natal', '3001 Germiston Branch', '2022-07-07 07:33:43', 'Paid', 'Germiston', 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_Id` int(8) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `DOJ` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Salary` bigint(20) NOT NULL,
  `Mobile_No` bigint(10) NOT NULL,
  `Email_Addr` varchar(256) NOT NULL,
  `Username` varchar(256) NOT NULL,
  `Staff_Password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_Id`, `Name`, `Gender`, `DOB`, `DOJ`, `Salary`, `Mobile_No`, `Email_Addr`, `Username`, `Staff_Password`) VALUES
(2, 'Mohau Matthews', 'Male', '1994-08-28', '2022-07-05 22:23:39', 56000, 747754527, 'matthapp94@gmail.com', 'Matthewsmohau', 'Kerrins@100'),
(5, 'Ndiliswa Tyobeka', 'Female', '2000-01-20', '2022-07-06 16:02:07', 39999, 726020485, 'ndiliswatyobeka@gmail.com', 'Ndiliswat', 'SA1@123');

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE `track` (
  `Id` int(10) NOT NULL,
  `Track_Id` int(9) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Current_Location` varchar(50) NOT NULL,
  `Dated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`Id`, `Track_Id`, `Status`, `Current_Location`, `Dated`) VALUES
(1, 1642051219, 'Order is Shipped', 'Head office', '2022-07-06 16:50:49'),
(2, 1642051219, 'Collected', 'Pretoria', '2022-07-06 16:51:02'),
(3, 779687255, 'Order is Shipped', 'Germiston', '2022-07-06 16:51:23'),
(4, 2081329497, 'Order is Shipped', 'Head Office', '2022-07-06 16:51:42'),
(5, 2081329497, 'Assigned to Rider', 'Pretoria', '2022-07-06 18:26:30'),
(11, 1507761732, 'Order is Shipped', '1055 Germiston Branch', '2022-07-06 16:49:02'),
(13, 1144148904, 'Order is Shipped', 'Head office', '2022-07-06 17:03:04'),
(14, 1144148904, 'Order is Shipped', 'Head office', '2022-07-06 17:03:22'),
(30, 1144148904, 'Order is Shipped', 'Head Office', '2022-07-06 17:16:21'),
(31, 2081329497, 'Delivered', 'Germiston', '2022-07-06 18:28:25'),
(34, 2081329497, 'Ready to be Collected', 'Germiston', '2022-07-06 18:30:42'),
(35, 2081329497, 'Collected', 'Germiston', '2022-07-06 18:31:32'),
(36, 2096309026, 'Order is Shipped', 'Kwa zulu natal', '2022-07-07 07:30:01'),
(37, 2096309026, 'Assigned to Rider', 'Johannesburg Head Office', '2022-07-07 07:32:36'),
(38, 2096309026, 'Delivered', 'Germiston', '2022-07-07 07:33:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`Branch_id`);

--
-- Indexes for table `dealerships`
--
ALTER TABLE `dealerships`
  ADD PRIMARY KEY (`D_id`);

--
-- Indexes for table `parcel`
--
ALTER TABLE `parcel`
  ADD PRIMARY KEY (`Parcel_Id`),
  ADD UNIQUE KEY `Track_Id` (`Track_Id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_Id`),
  ADD UNIQUE KEY `username` (`Username`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `Branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100328;

--
-- AUTO_INCREMENT for table `dealerships`
--
ALTER TABLE `dealerships`
  MODIFY `D_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `parcel`
--
ALTER TABLE `parcel`
  MODIFY `Parcel_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staff_Id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `track`
--
ALTER TABLE `track`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
